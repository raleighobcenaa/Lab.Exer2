package com.obcena.labact3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class Verify extends AppCompatActivity {

    EditText etUS, etUS1, etUS2, etUS3, etUS4, etUS5, etUS6, etUS7; //declaring variables
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);
        etUS = findViewById(R.id.editUS); //assigning value to the variable
        etUS1 = findViewById(R.id.editUS1); //assigning value to the variable
        etUS2 = findViewById(R.id.editUS2); //assigning value to the variable
        etUS3 = findViewById(R.id.editUS3); //assigning value to the variable
        etUS4 = findViewById(R.id.editUS4); //assigning value to the variable
        etUS5 = findViewById(R.id.editUS5); //assigning value to the variable
        etUS6 = findViewById(R.id.editUS6); //assigning value to the variable
        etUS7 = findViewById(R.id.editUS7); //assigning value to the variable
    }

    public void validate(View view){
        sp = getSharedPreferences("data1", MODE_PRIVATE); // mode private is a non static constant
        String usSP = sp.getString("user", null);
        String us = etUS.getText().toString();
        String us1 = etUS1.getText().toString();
        String us2 = etUS2.getText().toString();
        String us3 = etUS3.getText().toString();
        String us4 = etUS4.getText().toString();
        String us5 = etUS5.getText().toString();
        String us6 = etUS6.getText().toString();
        String us7 = etUS7.getText().toString();

        if (usSP.equals(us) || usSP.equals(us1) || usSP.equals(us2) || usSP.equals(us3) ||
                usSP.equals(us4) || usSP.equals(us5) || usSP.equals(us6)|| usSP.equals(us7)){
            Toast.makeText(this, "School exists in the UAAP Schools.", Toast.LENGTH_LONG);
        } else {
            Toast.makeText(this, "School does not exist in the UAAP Schools .", Toast.LENGTH_LONG);
        }
    }




}
